import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Data Member
        int belanja = 0;

        //membuat objek scanner baru
        Scanner input = new Scanner (System.in);

        System.out.print("Masukkan Total Belanja : ");
        belanja = input.nextInt();

        //cek apakah total belanja diatas 50000
        if (belanja >= 50000){
            System.out.println("Selamat Anda Mendapat Mouse");
        }else{
        System.out.println("Beanja Anda Kurang Dari Rp. 50.000");
        System.out.println("Tingkatkan Nilai belanja anda untuk mendapatkan hadiah");
        }
        System.out.println("Terimakasih!!!");
    }
    
}
