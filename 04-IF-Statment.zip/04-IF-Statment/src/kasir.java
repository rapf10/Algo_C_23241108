import java.util.Scanner;

public class kasir {
    public static void main(String[] args) {
        //menentukan variabel
        int nilai;
        Scanner input = new Scanner(System.in);

        //mengambil nilai
        System.out.println("Masukkan Nilai : ");
        nilai = input.nextInt();

        if(nilai>=80){
            System.out.println("Nilai anda A");
        }
        else if (nilai>=70 && nilai<=79){
            System.out.println("Nilai anda B");
        }
        else if (nilai>=60 && nilai<=69){
            System.out.println("Nilai anda C");
        }
        else if (nilai>=50 && nilai<=59){
            System.out.println("Nilai anda D");
        }
        else {
            System.out.println("Nilai anda E");
        }
    }
}
