public class Main {
    public static void main(String[] args) {
        //Membuat aplikasi Biodata
        //deklarasi variabel dan tipe data
        String nama;
        String nim;
        String prodi;
        String tanggal_lahir;
        float tinggi_badan;
        double berat_badan;
        boolean status; //jika menikah = True, Kalau belum menikah = False

        //mengisi nilai dalam variabel
        nama = "Rezka";
        nim = "23241109";
        prodi = "Pendidikian Teknologi Informasi";
        tanggal_lahir = "9 September 2005";
        tinggi_badan = 170.5f;
        berat_badan = 58.7d;
        status = true;

        //mencetak biodata ke layar komputer

        System.out.println("__________________________");
        System.out.println("Nama Mahasiswa :"+ nama);
        System.out.println("Nim Mahasiswa :"+ nim);
        System.out.println("Prodi :"+ prodi);
        System.out.println("Tangga Lahir :"+ tanggal_lahir);
        System.out.println("Tinggi Badan :"+ tinggi_badan);
        System.out.println("Berat Badan :"+ berat_badan);
        System.out.println("Status :"+ status);
        System.out.println("__________________________");
    }
    
}
